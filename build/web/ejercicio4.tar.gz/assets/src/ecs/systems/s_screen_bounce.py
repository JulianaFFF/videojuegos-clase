import esper
import pygame

from src.ecs.components.c_transform import CTransform
from src.ecs.components.c_velocity import CVelocity
from src.ecs.components.c_surface import CSurface
from src.ecs.components.tags.c_tag_enemy import CTagEnemy
from src.ecs.components.tags.c_tag_hunter import CTagHunter

def system_screen_bounce(world:esper.World, screen:pygame.Surface):
    screen_rect = screen.get_rect() 
    components = world.get_components(CTransform, CVelocity, CSurface, CTagEnemy)
    
    c_t:CTransform
    c_v:CVelocity
    c_s:CSurface
    c_e:CTagEnemy
    for enemy_entity, (c_t, c_v, c_s, c_e) in components:
        # El Hunter no rebota: su movimiento lo controla system_hunter_state
        if world.has_component(enemy_entity, CTagHunter):
            continue
        cuad_rect = CSurface.get_area_relative(c_s.area, c_t.pos)
        
        if (cuad_rect.left < 0 and c_v.vel.x < 0) or (cuad_rect.right > screen_rect.width and c_v.vel.x > 0):
            c_v.vel.x *= -1
            cuad_rect.clamp_ip(screen_rect)
            c_t.pos.x = cuad_rect.x
            
        if (cuad_rect.top < 0 and c_v.vel.y < 0) or (cuad_rect.bottom > screen_rect.height and c_v.vel.y > 0):
            c_v.vel.y *= -1
            cuad_rect.clamp_ip(screen_rect)
            c_t.pos.y = cuad_rect.y
