import esper
import pygame

from src.ecs.components.c_animation import CAnimation
from src.ecs.components.c_hunter_state import CHunterState, HunterState
from src.ecs.components.c_surface import CSurface
from src.ecs.components.c_transform import CTransform
from src.ecs.components.c_velocity import CVelocity
from src.ecs.components.tags.c_tag_hunter import CTagHunter
from src.engine.service_locator import ServiceLocator

def system_hunter_state(world:esper.World, player_entity:int, delta_time:float, hunter_info:dict):
    pl_t = world.component_for_entity(player_entity, CTransform)
    pl_s = world.component_for_entity(player_entity, CSurface)
    player_center = pygame.Vector2(CSurface.get_area_relative(pl_s.area, pl_t.pos).center)

    components = world.get_components(CTransform, CVelocity, CSurface, CAnimation, CHunterState, CTagHunter)
    for _, (c_t, c_v, c_s, c_a, c_hst, c_hun) in components:
        hunter_center = pygame.Vector2(CSurface.get_area_relative(c_s.area, c_t.pos).center)
        if c_hst.state == HunterState.IDLE:
            _do_idle_state(c_v, c_a, c_hst, c_hun, hunter_center, player_center, hunter_info)
        elif c_hst.state == HunterState.CHASE:
            _do_chase_state(c_t, c_v, c_a, c_hst, c_hun, hunter_center, player_center)
        elif c_hst.state == HunterState.RETURN:
            _do_return_state(c_t, c_v, c_a, c_hst, c_hun, delta_time)

def _do_idle_state(c_v:CVelocity, c_a:CAnimation, c_hst:CHunterState, c_hun:CTagHunter,
                   hunter_center:pygame.Vector2, player_center:pygame.Vector2, hunter_info:dict):
    c_v.vel.xy = (0, 0)
    c_a.set_animation("IDLE")
    if hunter_center.distance_to(player_center) <= c_hun.distance_start_chase:
        ServiceLocator.sounds_service.play(hunter_info["sound_chase"])
        c_hst.state = HunterState.CHASE

def _do_chase_state(c_t:CTransform, c_v:CVelocity, c_a:CAnimation, c_hst:CHunterState, c_hun:CTagHunter,
                    hunter_center:pygame.Vector2, player_center:pygame.Vector2):
    c_a.set_animation("MOVE")
    if c_t.pos.distance_to(c_hst.origin) >= c_hun.distance_start_return:
        c_hst.state = HunterState.RETURN
        return
    direction = player_center - hunter_center
    if direction.length_squared() > 0:
        c_v.vel = direction.normalize() * c_hun.velocity_chase
    else:
        c_v.vel.xy = (0, 0)

def _do_return_state(c_t:CTransform, c_v:CVelocity, c_a:CAnimation, c_hst:CHunterState, c_hun:CTagHunter,
                     delta_time:float):
    c_a.set_animation("MOVE")
    direction = c_hst.origin - c_t.pos
    # Si en este cuadro llegaria (o pasaria) el origen, se ubica en el origen y descansa
    if direction.length() <= c_hun.velocity_return * delta_time:
        c_t.pos.xy = c_hst.origin
        c_v.vel.xy = (0, 0)
        c_hst.state = HunterState.IDLE
        c_a.set_animation("IDLE")
        return
    c_v.vel = direction.normalize() * c_hun.velocity_return
