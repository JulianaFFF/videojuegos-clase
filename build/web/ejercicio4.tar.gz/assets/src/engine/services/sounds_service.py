import pygame

class SoundsService:
    def __init__(self) -> None:
        self._sounds = {}

    def get(self, path: str) -> pygame.mixer.Sound:
        if path not in self._sounds:
            self._sounds[path] = pygame.mixer.Sound(path)
        return self._sounds[path]
    
    def play(self, path: str):
        self.get(path).play()
