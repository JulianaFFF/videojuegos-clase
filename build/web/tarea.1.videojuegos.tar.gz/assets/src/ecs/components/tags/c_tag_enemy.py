class CTagEnemy:
    pass
