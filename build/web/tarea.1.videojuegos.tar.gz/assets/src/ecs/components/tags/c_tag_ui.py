class CTagUI:
    pass
