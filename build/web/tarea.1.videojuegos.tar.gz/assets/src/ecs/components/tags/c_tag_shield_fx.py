class CTagShieldFx:
    pass
