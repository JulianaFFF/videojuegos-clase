class CTagPlayer:
    pass
