class CTagBullet:
    pass
