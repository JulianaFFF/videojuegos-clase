class CTagHunter:
    pass
