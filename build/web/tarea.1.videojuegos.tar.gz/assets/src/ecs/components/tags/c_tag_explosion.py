class CTagExplosion:
    pass
