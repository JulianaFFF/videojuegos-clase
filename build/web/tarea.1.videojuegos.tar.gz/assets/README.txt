PENDIENTE_ENLACE_ITCH_IO

Nota: los recursos del curso no incluyen un sonido de movimiento. Se usa laser_special.ogg, el sonido más corto de los recursos, cuando el personaje empieza a moverse.
